--
-- PostgreSQL database dump
--

-- Dumped from database version 15.12 (Ubuntu 15.12-1.pgdg20.04+1)
-- Dumped by pg_dump version 15.12 (Ubuntu 15.12-1.pgdg20.04+1)

-- Started on 2025-09-22 17:09:42 +07

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS house_design;
--
-- TOC entry 3350 (class 1262 OID 65541)
-- Name: house_design; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE house_design WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


\connect house_design

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 215 (class 1259 OID 65544)
-- Name: admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL
);


--
-- TOC entry 214 (class 1259 OID 65543)
-- Name: admin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3351 (class 0 OID 0)
-- Dependencies: 214
-- Name: admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_id_seq OWNED BY public.admin.id;


--
-- TOC entry 221 (class 1259 OID 73734)
-- Name: articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.articles (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    content text NOT NULL,
    summary text,
    featured_image_url character varying(500),
    category_id integer NOT NULL,
    published boolean DEFAULT false,
    tags character varying(1000),
    meta_title character varying(255),
    meta_description text,
    slug character varying(500) NOT NULL,
    author_id integer,
    view_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 220 (class 1259 OID 73733)
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3352 (class 0 OID 0)
-- Dependencies: 220
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- TOC entry 217 (class 1259 OID 65555)
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    parent_id integer,
    level integer DEFAULT 0,
    order_index integer DEFAULT 0,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    thumbnail_url character varying(500)
);


--
-- TOC entry 216 (class 1259 OID 65554)
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3353 (class 0 OID 0)
-- Dependencies: 216
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- TOC entry 219 (class 1259 OID 65568)
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    content text,
    summary text,
    image_url character varying(500),
    category_id integer NOT NULL,
    published boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 218 (class 1259 OID 65567)
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3354 (class 0 OID 0)
-- Dependencies: 218
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- TOC entry 3160 (class 2604 OID 65547)
-- Name: admin id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin ALTER COLUMN id SET DEFAULT nextval('public.admin_id_seq'::regclass);


--
-- TOC entry 3172 (class 2604 OID 73737)
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- TOC entry 3161 (class 2604 OID 65558)
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- TOC entry 3168 (class 2604 OID 65571)
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- TOC entry 3338 (class 0 OID 65544)
-- Dependencies: 215
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin (id, username, password) FROM stdin;
1	admin	$2a$10$JfR2QsWB550roQU07pIrDus0vj6s5c8s171qw12NQlVb4CQVFeR..
\.


--
-- TOC entry 3344 (class 0 OID 73734)
-- Dependencies: 221
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.articles (id, title, content, summary, featured_image_url, category_id, published, tags, meta_title, meta_description, slug, author_id, view_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3340 (class 0 OID 65555)
-- Dependencies: 217
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, slug, description, created_at, updated_at, parent_id, level, order_index, is_active, display_order, thumbnail_url) FROM stdin;
1	Dự Án Thiết Kế	du-an-thiet-ke	Các mẫu thiết kế nhà hiện đại	2025-09-12 15:45:53.499091	2025-09-22 16:18:45.885833	\N	0	0	f	1	
13	Công trình thiết kế	cong-trinh-thiet-ke	Các dự án thực tế	2025-09-18 00:14:02.001945	2025-09-22 16:18:45.885833	\N	0	3	t	2	\N
2	Tin Tức	tin-tuc	Tin tức về kiến trúc và xây dựng	2025-09-12 15:45:53.500192	2025-09-22 16:18:45.885833	\N	0	2	t	3	\N
\.


--
-- TOC entry 3342 (class 0 OID 65568)
-- Dependencies: 219
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, title, content, summary, image_url, category_id, published, created_at, updated_at) FROM stdin;
2	Hehe	<blockquote><ul><li>adadaba<br>blablo</li><li>đâ</li></ul></blockquote>	hehehehe	http://localhost:8080/data/uploads/images/cb7c129f-6027-4a16-b2b8-0ba88fb27650.png	2	t	2025-09-17 14:15:36.206545	2025-09-17 14:15:40.677293
1	DAta	<p>test noi dung Website thiết kế nhà hiện đại với hệ thống quản lý nội dung admin. Dự án bao gồm:</p><figure class="image image-style-side"><img style="aspect-ratio:804/534;" src="http://localhost:8080/data/uploads/images/39705328-a334-48a6-9929-65ce8b4d65e1.png" width="804" height="534"></figure><ul><li><strong>Frontend</strong>: Angular 17+ với TypeScript và Angular Material</li><li><strong>Backend</strong>: Go với Gin framework và PostgreSQL database</li><li><strong>Chức năng</strong>: Landing page, quản lý danh mục, quản lý bài đăng, xác thực admin</li><li><h3><strong>Claude Max 20x ($200/month)</strong></h3></li><li><strong>Extensive limits</strong>: Community reports from <a href="https://www.reddit.com/r/ClaudeAI/">r/ClaudeAI</a> consistently show users never running out of allocation during normal development usage. This tier provides 20x the Pro allocation, which is substantial enough for teams, multiple concurrent projects, or extremely intensive development workflows.</li></ul><p><strong>Opus access</strong>: You'll have sufficient Opus allocation for multiple parallel sessions, extensive architectural planning, and complex problem-solving throughout the day. This tier removes the strategic constraints of lower tiers and lets you use Opus freely when needed.</p><p><strong>Professional workflows</strong>: Designed to support intensive development without interruption. Ideal for full-time developers, technical leads, or anyone who needs unrestricted access for professional workflows including code reviews, architectural decisions, and complex debugging sessions.</p><p><strong>Reset frequency</strong>: Your usage resets every 5 hours with 20x the Pro allocation. Starting August 28, 2024, weekly limits will be introduced that are generous enough to support normal development workflows without impact for most users.</p>	Test tom tat	http://localhost:8080/data/uploads/images/a8d97bcf-dd94-4721-b5f5-1904bfe48bb9.png	2	f	2025-09-17 07:58:30.831799	2025-09-17 18:09:15.745961
\.


--
-- TOC entry 3355 (class 0 OID 0)
-- Dependencies: 214
-- Name: admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_id_seq', 1, true);


--
-- TOC entry 3356 (class 0 OID 0)
-- Dependencies: 220
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.articles_id_seq', 1, false);


--
-- TOC entry 3357 (class 0 OID 0)
-- Dependencies: 216
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 39, true);


--
-- TOC entry 3358 (class 0 OID 0)
-- Dependencies: 218
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 2, true);


--
-- TOC entry 3178 (class 2606 OID 65551)
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (id);


--
-- TOC entry 3180 (class 2606 OID 65553)
-- Name: admin admin_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_username_key UNIQUE (username);


--
-- TOC entry 3188 (class 2606 OID 73745)
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- TOC entry 3190 (class 2606 OID 73747)
-- Name: articles articles_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_slug_key UNIQUE (slug);


--
-- TOC entry 3182 (class 2606 OID 65564)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3184 (class 2606 OID 65566)
-- Name: categories categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_key UNIQUE (slug);


--
-- TOC entry 3186 (class 2606 OID 65578)
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- TOC entry 3193 (class 2606 OID 73748)
-- Name: articles articles_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.admin(id);


--
-- TOC entry 3194 (class 2606 OID 73753)
-- Name: articles articles_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- TOC entry 3191 (class 2606 OID 81928)
-- Name: categories categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- TOC entry 3192 (class 2606 OID 65579)
-- Name: posts posts_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


-- Completed on 2025-09-22 17:09:42 +07

--
-- PostgreSQL database dump complete
--

